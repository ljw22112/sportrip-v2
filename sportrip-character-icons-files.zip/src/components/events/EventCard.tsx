'use client';
import Link from 'next/link';
import { SportEvent } from '@/types';
import { calcDday } from '@/lib/data';
import { getSportInfo } from '@/lib/sports';
import { SportIcon } from './SportIcon';
import { useState, useEffect, useCallback, useId } from 'react';

function fmtDate(ds: string) {
  const [y,m,d] = ds.split('-').map(Number);
  return `${m}.${String(d).padStart(2,'0')} (${'일월화수목금토'[new Date(Date.UTC(y,m-1,d)).getUTCDay()]})`;
}

const LS_KEY = 'sportrip_saved';
export function getSavedIds(): Set<string> {
  if (typeof window==='undefined') return new Set();
  try { return new Set(JSON.parse(localStorage.getItem(LS_KEY)||'[]')); } catch { return new Set(); }
}
export function toggleSaved(id: string): boolean {
  const s = getSavedIds();
  s.has(id) ? s.delete(id) : s.add(id);
  localStorage.setItem(LS_KEY, JSON.stringify([...s]));
  return s.has(id);
}

export function EventCard({ event }: { event: SportEvent }) {
  const [saved, setSaved] = useState(false);
  const sport = getSportInfo(event.sport);
  useEffect(()=>{ setSaved(getSavedIds().has(String(event.id))); },[event.id]);
  const handleHeart = useCallback((e: React.MouseEvent)=>{
    e.preventDefault(); e.stopPropagation();
    setSaved(toggleSaved(String(event.id)));
  },[event.id]);

  return (
    <article className="relative group cursor-pointer">
      {/* 썸네일 — 테두리만, 흰 배경, 종목 캐릭터 */}
      <Link href={`/events/${event.id}`}
        className="relative block rounded-2xl overflow-hidden border-2 hover:border-[--green] transition-all bg-white"
        style={{aspectRatio:'1/1', borderColor: sport.color + '55'}}>
        {/* D-day 배지 */}
        {event.status !== 'done' && (
          <div className="absolute top-2.5 left-2.5 text-white text-[11px] font-bold px-2.5 py-1 rounded-full z-10"
            style={{background: sport.color}}>
            {calcDday(event.start)}
          </div>
        )}
        {/* 종목 캐릭터 (이미지/이모지) */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="w-[70%] md:w-[65%] mb-2 select-none">
            <SportIcon sport={event.sport} className="w-full h-auto object-contain" emojiClassName="text-[60px] md:text-[72px] leading-none block" />
          </div>
          <div className="text-[11px] font-bold px-3 py-1 rounded-full text-white"
            style={{background: sport.color}}>
            {event.sport}
          </div>
        </div>
        {/* 하단 날짜 바 */}
        <div className="absolute bottom-0 left-0 right-0 px-3 py-2.5"
          style={{background: sport.color + 'EE'}}>
          <div className="text-white font-bold text-[13px] tracking-tight">{fmtDate(event.start)}</div>
          <div className="text-white/80 text-[11px] mt-0.5">{event.region}</div>
        </div>
      </Link>
      {/* 하트 */}
      <button onClick={handleHeart} aria-label={saved?'저장 해제':'저장'}
        className="absolute top-2.5 right-2.5 w-8 h-8 flex items-center justify-center text-lg z-10 hover:scale-110 transition-transform">
        {saved ? '❤️' : '🤍'}
      </button>
      {/* 텍스트 */}
      <Link href={`/events/${event.id}`} className="block pt-2.5 px-0.5">
        <div className="font-bold text-[14px] text-[#222] truncate leading-tight">{event.title}</div>
        <div className="text-[13px] text-[#717171] mt-0.5">{event.region} · {event.sport}</div>
        <div className="text-[13px] text-[#717171] mt-0.5">{fmtDate(event.start)}</div>
      </Link>
    </article>
  );
}

export function EventCardSkeleton() {
  return (
    <div>
      <div className="rounded-2xl bg-gray-100 animate-pulse border-2 border-gray-200" style={{aspectRatio:'1/1'}}/>
      <div className="h-4 w-3/5 bg-gray-100 rounded mt-2.5 animate-pulse"/>
      <div className="h-3.5 w-2/5 bg-gray-100 rounded mt-1.5 animate-pulse"/>
    </div>
  );
}

export function EventCardHorizontal({ event }: { event: SportEvent }) {
  const sport = getSportInfo(event.sport);
  const [saved, setSaved] = useState(false);
  useEffect(()=>{ setSaved(getSavedIds().has(String(event.id))); },[event.id]);
  return (
    <Link href={`/events/${event.id}`}
      className="flex gap-4 py-4 border-b border-[#E8E8E6] items-center hover:bg-[#F7F7F6] px-2 -mx-2 rounded-xl transition-colors">
      <div className="w-14 h-14 flex-shrink-0 rounded-xl flex items-center justify-center p-1.5 border-2"
        style={{borderColor: sport.color + '55', background: sport.color + '11'}}>
        <SportIcon sport={event.sport} className="w-full h-full object-contain" emojiClassName="text-3xl" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="font-bold text-[14px] text-[#222] truncate">{event.title}</div>
        <div className="text-[13px] text-[#717171] mt-0.5">{event.region} · {event.sport}</div>
        <div className="text-[13px] text-[#717171] mt-0.5">
          {event.start}
          {event.status!=='done' && <span className="font-bold ml-2" style={{color:sport.color}}>{calcDday(event.start)}</span>}
        </div>
      </div>
      <span className="text-base flex-shrink-0">{saved?'❤️':'🤍'}</span>
    </Link>
  );
}
